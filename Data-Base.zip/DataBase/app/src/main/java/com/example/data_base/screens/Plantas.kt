package com.example.data_base.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.data_base.models.Alumno
import com.example.data_base.models.AlumnosViewModel
import com.example.data_base.navigation.AppScreens



@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Pantalla(navController: NavHostController, viewModel: AlumnosViewModel) {

    LazyColumn() {
        items(viewModel.alumnos.value) { alumno ->
            Plantas(alumno)
        }
    }

    Row(Modifier.height(100.dp)) {

        Column(
            Modifier.height(200.dp)
                .padding(start = 50.dp)
        ) {
            Button(onClick = { navController.navigate(route = AppScreens.Home.route) }) {
                Text(text = "Plantas")

            }
        }
        Column(
            Modifier.height(200.dp)
                .padding(start = 50.dp)
        ) {
            Button(onClick = { navController.navigate(route = AppScreens.Plantas.route) }) {
                Text(text = "Ver info detallada")
            }
        }
    }



}



    @Composable
    fun Plantas(
        alumno: Alumno
    ) {

        Card() {
            Column(modifier = Modifier.fillMaxWidth()
                .padding(top = 100.dp)) {
                Text(text = " ${alumno.codigo}", color = Color.DarkGray, fontSize = 16.sp)
                Column() {
                    Text(text = "Nombre ${alumno.nombre}", color = Color.DarkGray, fontSize = 16.sp)
                    Text(text = "Descripcion ${alumno.grupo}", color = Color.DarkGray, fontSize = 16.sp)
                }
            }

        }
    }








