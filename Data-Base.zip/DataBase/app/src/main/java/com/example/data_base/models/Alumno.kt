package com.example.data_base.models


data class Alumno(
    val nombre: String="",
    val grupo: String="",
    val codigo: String="",

    )//fin del la clase
