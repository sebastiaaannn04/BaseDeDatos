package com.example.data_base.navigation

sealed class AppScreens (val route: String){
    object Home : AppScreens(route = "Home")
    object AddScreen : AppScreens(route = "AddScreen")
    object LoginScreen : AppScreens(route = "LoginScreen")
    object Plantas : AppScreens(route = "Plantas")

}